// ==============================================================
//  POS BACKEND
//  src/app-orders/app-orders.service.ts
//  >> CHEP DE (thay file co san)
// ==============================================================

// ==================================================================
//  POS BACKEND  (NestJS + raw pg)
//  Dat tai:  src/app-orders/app-orders.service.ts
//  >> CHEP DE — them helper printProductStamps + moc vao receiveFromApp
// ==================================================================

import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { DashboardService } from '../dashboard/dashboard.service';
import { PrintingService } from '../printing/printing.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { ReceiveAppOrderDto } from './dto/receive-app-order.dto';
import { AppOrderItem, AppOrderView, PrepStatus } from './app-orders.types';

interface AppOrderRow {
  id: string;
  app_order_id: string;
  order_code: string;
  fulfillment: 'DELIVERY' | 'PICKUP';
  payment_method: 'COD' | 'BANK_QR';
  payment_status: 'PENDING' | 'PAID';
  customer_name: string | null;
  customer_phone: string | null;
  customer_address: string | null;
  items: AppOrderItem[];
  total_amount: number;
  prep_status: PrepStatus;
  note: string | null;
  received_at: Date;
}

@Injectable()
export class AppOrdersService {
  private readonly logger = new Logger('AppOrders');
  constructor(
    private readonly db: DatabaseService,
    private readonly printing: PrintingService,
    private readonly realtime: RealtimeGateway,
    private readonly dashboard: DashboardService, // @Global -> không cần import module
  ) {}

  // =========================================================================
  //  NHẬN ĐƠN TỪ APP (gọi qua mạng nội bộ)
  // =========================================================================
  /**
   * Lưu đơn online, IN PHIẾU BẾP, bắn realtime cho thu ngân.
   * Idempotent: app_order_id UNIQUE + ON CONFLICT DO NOTHING -> gửi lại không trùng.
   * Đơn BANK_QR đẩy sang khi đã trả -> set paid_at + cộng doanh thu ngay.
   */
  async receiveFromApp(
    dto: ReceiveAppOrderDto,
  ): Promise<{ ok: true; id: number; duplicated: boolean }> {
    try {
    const paymentStatus = dto.paymentStatus ?? 'PENDING';
    // Tính paid_at ở JS (đơn đã trả -> NOW). TRÁNH tái dùng $5 trong SQL:
    // dùng $5 vừa cho cột enum vừa cho `$5 = 'PAID'` khiến Postgres suy ra
    // 2 kiểu khác nhau -> lỗi "inconsistent types deduced for parameter $5".
    const paidAt = paymentStatus === 'PAID' ? new Date() : null;

    const inserted = await this.db.queryOne<{ id: number }>(
      `INSERT INTO app_orders
         (app_order_id, order_code, fulfillment, payment_method, payment_status,
          customer_name, customer_phone, customer_address, items, total_amount,
          prep_status, note, received_at, paid_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10,$11,$12,
               COALESCE($13::timestamptz, NOW()),
               $14::timestamptz)
       ON CONFLICT (app_order_id) DO NOTHING
       RETURNING id`,
      [
        dto.appOrderId,
        dto.orderCode,
        dto.fulfillment,
        dto.paymentMethod,
        paymentStatus,
        dto.customer?.name ?? null,
        dto.customer?.phone ?? null,
        dto.customer?.address ?? null,
        JSON.stringify(dto.items),
        dto.totalAmount,
        dto.status ?? 'CONFIRMED',
        dto.note ?? null,
        dto.createdAt ?? null,
        paidAt,
      ],
    );

    await this.db.query(
      `INSERT INTO processed_events (event_id) VALUES ($1) ON CONFLICT DO NOTHING`,
      [dto.eventId],
    );

    if (!inserted) {
      const existing = await this.getRowByAppId(dto.appOrderId);
      return { ok: true, id: existing ? Number(existing.id) : 0, duplicated: true };
    }

    const view = await this.getViewById(Number(inserted.id));

    // In phiếu bếp chạy NỀN — không để máy in làm treo response trả về App.
    void this.printing
      .printAppOrder(view)
      .then(() => {
        // IN TEM DÁN LY chạy nền ngay sau khi in phiếu bếp xong.
        // (printProductStamps tự bao try/catch -> không bao giờ reject.)
        void this.printProductStamps(view);
        // Đánh dấu đã in phiếu (lỗi DB nếu có sẽ rơi vào .catch bên dưới).
        return this.db.query(
          `UPDATE app_orders SET printed_at = NOW() WHERE id = $1 AND printed_at IS NULL`,
          [inserted.id],
        );
      })
      .catch((e) =>
        this.logger.warn(
          `In đơn ${view.orderCode} lỗi nền: ${e instanceof Error ? e.message : String(e)}`,
        ),
      );

    this.realtime.emitAppOrderIncoming({
      id: view.id,
      appOrderId: view.appOrderId,
      orderCode: view.orderCode,
      fulfillment: view.fulfillment,
      total: view.totalAmount,
      customerName: view.customerName,
      itemCount: view.items.length,
    });

    // Đơn đã trả trước (BANK_QR) -> cộng doanh thu ngay.
    if (paymentStatus === 'PAID') {
      void this.dashboard.broadcastTodayRevenue();
    }

    return { ok: true, id: view.id, duplicated: false };
    } catch (e) {
      // Lộ nguyên nhân 500 thật (constraint/enum/kiểu dữ liệu) thay vì
      // "Internal server error" chung chung mà App nhận được.
      this.logger.error(
        `Nhận đơn ${dto.orderCode} (${dto.appOrderId}) LỖI: ` +
          `${e instanceof Error ? e.message : String(e)} | ` +
          `fulfillment=${dto.fulfillment} pay=${dto.paymentMethod}/` +
          `${dto.paymentStatus ?? 'PENDING'} status=${dto.status ?? 'CONFIRMED'} ` +
          `total=${dto.totalAmount} items=${dto.items?.length ?? 0}`,
      );
      throw e;
    }
  }

  // =========================================================================
  //  CHO MÀN THU NGÂN
  // =========================================================================
  /**
   * Đơn online đang cần xử lý: chưa hủy VÀ chưa (giao xong + đã thu tiền).
   * -> đơn COD đã giao nhưng CHƯA thu tiền vẫn hiện để bấm "Đã thu tiền".
   */
  async listActive(): Promise<AppOrderView[]> {
    const rows = await this.db.query<AppOrderRow>(
      `SELECT * FROM app_orders
        WHERE prep_status <> 'CANCELLED'
          AND NOT (prep_status = 'DELIVERED' AND payment_status = 'PAID')
        ORDER BY received_at`,
    );
    return rows.map((r) => this.toView(r));
  }

  /** Thu ngân đổi trạng thái chế biến -> cập nhật + đẩy về App qua outbox. */
  async updateStatus(appOrderId: string, status: PrepStatus): Promise<AppOrderView> {
    const row = await this.getRowByAppId(appOrderId);
    if (!row) throw new NotFoundException(`Không tìm thấy đơn online ${appOrderId}`);
    if (row.prep_status === 'DELIVERED' || row.prep_status === 'CANCELLED') {
      throw new BadRequestException('Đơn đã kết thúc, không đổi trạng thái được');
    }

    await this.db.query(
      `UPDATE app_orders SET prep_status = $2, updated_at = NOW() WHERE app_order_id = $1`,
      [appOrderId, status],
    );

    // Đẩy trạng thái về App (worker outbox -> POST /internal/orders/status).
    await this.db.query(
      `INSERT INTO sync_outbox (event_type, payload) VALUES ('app_order.status', $1)`,
      [JSON.stringify({ appOrderId, status })],
    );

    const view = await this.getViewByAppId(appOrderId);
    this.emitStatus(view);
    return view;
  }

  /**
   * App báo khách ĐÃ NHẬN HÀNG -> đánh dấu đơn đã giao (DELIVERED).
   * Idempotent, KHÔNG đẩy ngược 'app_order.status' về App (App đã tự set).
   */
  async markReceivedFromApp(
    appOrderId: string,
  ): Promise<{ ok: true; applied: boolean }> {
    const row = await this.getRowByAppId(appOrderId);
    if (!row) return { ok: true, applied: false };
    if (row.prep_status === 'DELIVERED' || row.prep_status === 'CANCELLED') {
      return { ok: true, applied: false };
    }
    await this.db.query(
      `UPDATE app_orders SET prep_status = 'DELIVERED', updated_at = NOW() WHERE app_order_id = $1`,
      [appOrderId],
    );
    const view = await this.getViewByAppId(appOrderId);
    this.emitStatus(view);
    return { ok: true, applied: true };
  }

  /** Xác nhận đã thu tiền (chủ yếu cho COD sau khi giao) -> ghi nhận doanh thu. */
  async confirmPayment(appOrderId: string): Promise<AppOrderView> {
    const row = await this.getRowByAppId(appOrderId);
    if (!row) throw new NotFoundException(`Không tìm thấy đơn online ${appOrderId}`);
    if (row.payment_status === 'PAID') {
      return this.toView(row); // đã thu rồi -> idempotent
    }

    await this.db.query(
      `UPDATE app_orders
          SET payment_status = 'PAID', paid_at = NOW(), updated_at = NOW()
        WHERE app_order_id = $1`,
      [appOrderId],
    );

    // Báo App: đã nhận tiền -> App set payment CONFIRMED (để tính vào hạng
    // khi đơn đã DELIVERED). Worker outbox -> POST /internal/orders/payment-received.
    await this.db.query(
      `INSERT INTO sync_outbox (event_type, payload) VALUES ('app_order.payment_received', $1)`,
      [JSON.stringify({ appOrderId })],
    );

    const view = await this.getViewByAppId(appOrderId);
    this.emitStatus(view);
    void this.dashboard.broadcastTodayRevenue();
    return view;
  }

  // =========================================================================
  //  KHÁCH HỦY ĐƠN TỪ APP (App gọi qua mạng nội bộ)
  // =========================================================================
  /**
   * App báo khách đã hủy -> set CANCELLED + cảnh báo các máy POS (chuông + thẻ đỏ).
   * KHÔNG đẩy ngược lại App (App đã tự cập nhật + báo khách rồi).
   */
  async cancelFromApp(
    appOrderId: string,
  ): Promise<{ ok: true; applied: boolean }> {
    const row = await this.getRowByAppId(appOrderId);
    // Đơn chưa từng đẩy sang POS (vd BANK_QR chưa trả) -> bỏ qua êm.
    if (!row) return { ok: true, applied: false };
    if (row.prep_status === 'DELIVERED' || row.prep_status === 'CANCELLED') {
      return { ok: true, applied: false }; // quá muộn / đã hủy
    }

    await this.db.query(
      `UPDATE app_orders SET prep_status = 'CANCELLED', updated_at = NOW() WHERE app_order_id = $1`,
      [appOrderId],
    );

    const view = await this.getViewByAppId(appOrderId);
    this.realtime.emitAppOrderCancelled({
      id: view.id,
      appOrderId: view.appOrderId,
      orderCode: view.orderCode,
    });
    return { ok: true, applied: true };
  }

  // =========================================================================
  //  HELPER
  // =========================================================================
  /**
   * IN TEM DÁN LY/MÓN — chạy NỀN, không chặn luồng nhận đơn.
   *
   * Phân rã giỏ hàng về từng ly: món số lượng N -> in N tem rời. Đánh số
   * TUYẾN TÍNH toàn đơn "Ly X / Y" (Y = tổng số ly cả đơn; X chạy liên tục,
   * KHÔNG reset theo từng món).
   *
   * Ví dụ: 2 Trà Sữa + 1 Cà Phê -> 3 tem: "Ly 1/3", "Ly 2/3", "Ly 3/3".
   */
  private async printProductStamps(view: AppOrderView): Promise<void> {
    try {
      // [B1] Tổng số ly toàn đơn (mẫu số Y) — sum mọi item.quantity.
      const totalCups = view.items.reduce((sum, it) => sum + it.quantity, 0);

      // [B2] Biến đếm tuyến tính toàn đơn (tử số X), khởi tạo NGOÀI vòng lặp.
      let currentCup = 1;

      // [B3] Vòng lặp lồng nhau: ngoài duyệt món, trong chạy theo số lượng ly.
      for (const item of view.items) {
        // Topping/đường-đá có thể nằm trong JSONB nhưng chưa khai báo ở type
        // AppOrderItem -> đọc an toàn, mặc định [] khi App chưa gửi.
        const options =
          (item as AppOrderItem & { options?: unknown[] }).options ?? [];

        for (let i = 1; i <= item.quantity; i++) {
          await this.printing.printProductStamp({
            orderCode: view.orderCode,
            customerName: view.customerName ?? 'Khách App',
            customerPhone: view.customerPhone ?? '',
            fulfillment: view.fulfillment,
            itemName: item.name,
            currentCup,
            totalCups,
            options,
            note: item.note ?? '',
          });
          currentCup++;
        }
      }

      this.logger.log(`Đã in ${totalCups} tem ly cho đơn ${view.orderCode}`);
    } catch (e) {
      // Máy in tem lỗi (hết giấy / mất mạng) -> CHỈ cảnh báo log, KHÔNG làm
      // sập luồng nhận đơn chính.
      this.logger.warn(
        `In tem ly đơn ${view.orderCode} lỗi nền: ${
          e instanceof Error ? e.message : String(e)
        }`,
      );
    }
  }

  private emitStatus(view: AppOrderView): void {
    this.realtime.emitAppOrderStatus({
      id: view.id,
      appOrderId: view.appOrderId,
      orderCode: view.orderCode,
      prepStatus: view.prepStatus,
      paymentStatus: view.paymentStatus,
    });
  }

  private getRowByAppId(appOrderId: string): Promise<AppOrderRow | null> {
    return this.db.queryOne<AppOrderRow>(
      `SELECT * FROM app_orders WHERE app_order_id = $1`,
      [appOrderId],
    );
  }

  private async getViewById(id: number): Promise<AppOrderView> {
    const row = await this.db.queryOne<AppOrderRow>(
      `SELECT * FROM app_orders WHERE id = $1`,
      [id],
    );
    if (!row) throw new NotFoundException(`Không tìm thấy đơn online #${id}`);
    return this.toView(row);
  }

  private async getViewByAppId(appOrderId: string): Promise<AppOrderView> {
    const row = await this.getRowByAppId(appOrderId);
    if (!row) throw new NotFoundException(`Không tìm thấy đơn online ${appOrderId}`);
    return this.toView(row);
  }

  private toView(r: AppOrderRow): AppOrderView {
    return {
      id: Number(r.id),
      appOrderId: r.app_order_id,
      orderCode: r.order_code,
      fulfillment: r.fulfillment,
      paymentMethod: r.payment_method,
      paymentStatus: r.payment_status,
      customerName: r.customer_name,
      customerPhone: r.customer_phone,
      customerAddress: r.customer_address,
      items: r.items ?? [],
      totalAmount: Number(r.total_amount),
      prepStatus: r.prep_status,
      note: r.note,
      receivedAt: r.received_at,
    };
  }
}